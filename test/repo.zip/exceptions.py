class RepoError(Exception):
    pass

class ValidError(Exception):
    pass

class UIError(Exception):
    pass